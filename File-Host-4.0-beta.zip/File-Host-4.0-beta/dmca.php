<?php
$name = "Digital Millennium Copyright Act (DMCA)";
 include('header.php');
?><div class="container">		<br>		<div class="card p-4">			<h5><i style="color:green;" class="fa fa-file-text-o"></i>&nbsp;Digital Millennium Copyright Act (DMCA)</h5>			<hr>						<div class="page-content">							<p> <strong><?= $_SERVER['HTTP_HOST']; ?></strong> intends to fully comply with the Digital Millennium Copyright Act ("DMCA"), including the notice and "take down" Provisions, and to benefit from the safe harbors immunizing <strong><?= $_SERVER['HTTP_HOST']; ?></strong> from liability to the fullest extent of the law. <strong><?= $_SERVER['HTTP_HOST']; ?></strong> reserves the right to terminate the account of any Member who infringes upon the copyright rights of others upon receipt of proper notification by the copyright owner or the copyright owner's legal agent. Included below are the processes and procedures that <strong><?= $_SERVER['HTTP_HOST']; ?></strong> will follow to resolve any claims of intellectual property violations.
It’s against our policies/terms to post copyrighted material you don’t have the authorization to use. If anybody find any link on our site which violate our terms in any case than report us asapgamil:- dmca@yahoo.com</p>		</div>		</div>		<br>		</div></div>
<?php
		
		include('footer.php');
?>
