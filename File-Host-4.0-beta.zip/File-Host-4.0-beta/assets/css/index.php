<?php
header('Location: /');
?>
