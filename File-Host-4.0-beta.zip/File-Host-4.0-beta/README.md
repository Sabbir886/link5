# File-Host

It's File Protector PHP Script maked by Shakib Ahmed

# Futures

1. Mediafire.com

2. Google.com

3. Yandex.com

4. Send.cm

5. Bayfiles.com

6. Anonfiles.com
 
7. Dropbox.com

8. Zippyshare.com

# Demo

https://file-host.herokuapp.com

# Contact Us

Facebook :- https://facebook.com/expertskb

Telegram :- https://t.me/expertskb

Email :- hello@shakib.cyou

URL :- https://shakib.cyou


# Installation

https://file-host.herokuapp.com/readme.txt
